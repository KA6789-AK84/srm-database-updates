// generate-distributed-assignments.ts

type Assign = {
  
  employee_id:     number;
  project_id:      number;
  group_id:        number;
  shift_id:        number;
  assignment_date: string;    // 'YYYY-MM-DD'
  hours_planned:   number;    // fixed 9
  overlap_minutes: number;    // fixed 1
  status:          string;    // 'weekoffs' or ''
};

// define each group’s weekoff weekdays
const weekoffs: Record<number, number[]> = {
  1: [6, 0],   // Sat, Sun
  2: [1, 2],   // Mon, Tue
  3: [3, 4],   // Wed, Thu
};

// map each employee to a (group, shift)
// 18 employees → 9 combos, 2 emp per combo
const employees: { emp: number; group: number; shift: number }[] = [];
let e = 1;
for (let g = 1; g <= 3; g++) {
  for (let s = 1; s <= 3; s++) {
    for (let k = 0; k < 2; k++) {
      if (e <= 18) employees.push({ emp: e++, group: g, shift: s });
    }
  }
}

// collect all dates of this month
const today = new Date();
const year = today.getFullYear();
const month = today.getMonth(); // 0–11
const start = new Date(year, month, 1);
const end   = new Date(year, month + 1, 0);
const dates: Date[] = [];
for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
  dates.push(new Date(d));
}

// build rows
const rows: Assign[] = [];
let id = 1;
for (const {emp, group, shift} of employees) {
  const offs = weekoffs[group];
  for (const d of dates) {
    const isOff = offs.includes(d.getDay());
    rows.push({
      employee_id:     emp,
      project_id:      1,
      group_id:        group,
      shift_id:        shift,
      assignment_date: d.toISOString().slice(0,10),
      hours_planned:   9,
      overlap_minutes: 1,
      status:          isOff ? 'weekoffs' : ''
    });
  }
}

// print bulk INSERT
const cols = [
  'employee_id','project_id','group_id',
  'shift_id','assignment_date','hours_planned',
  'overlap_minutes','status'
].join(', ');

const vals = rows.map(r =>
  `(${r.employee_id},${r.project_id},${r.group_id},` +
  `${r.shift_id},'${r.assignment_date}',${r.hours_planned},` +
  `${r.overlap_minutes},'${r.status}')`
).join(',\n');

console.log(`INSERT INTO organization.assignments (${cols})\nVALUES\n${vals};`);
